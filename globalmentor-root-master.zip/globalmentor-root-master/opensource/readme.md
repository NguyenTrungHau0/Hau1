# GlobalMentor Open-Source Root POM

Root POM for GlobalMentor public open-soruce projects.

## Issues

Issues tracked by [JIRA](https://globalmentor.atlassian.net/projects/JAVA).
